function Loo = calc_envL( left_maxE, iMPS, oooMPO )





    
    
                    
end  
        
        
end
                    

                    
