function SOP_check(n,SizeCell)
%n = 1 ==> ABCD
%n = 2 ==> BCDA
%n = 3 ==> CDBA
%n = 4 ==> DABC

if n > SizeCell
    print(' ')
    print(' ')
    print(' ')
    print('error in StringOrderParameter')
    print(' n > SizeCell')
    print(' ')
    print(' ')
    print(' ')
    pause
    pause
        pause
    pause
        pause
    pause
    return
end