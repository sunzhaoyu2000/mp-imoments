function norm_ = normalization_leftrighteigenvector_of_T(left_maxE, right_maxE)

norm_ = left_maxE.' * right_maxE; 

end
